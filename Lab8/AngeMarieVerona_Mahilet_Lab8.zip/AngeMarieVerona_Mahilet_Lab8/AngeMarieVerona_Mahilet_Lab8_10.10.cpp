#include <iostream>
using namespace std;

class RationalNumber {
private:
    int num; 
    int den;

    // Compute gcd 
    int gcd(int a, int b) const {
        if (a < 0) a = -a;
        if (b < 0) b = -b;
        while (b != 0) {
            int t = a % b;
            a = b;
            b = t;
        }
        return a == 0 ? 1 : a;
    }

    // Reduce and correct signs
    void normalize() {
        if (den == 0) {
            cout << "Error: the denominators cannot be '0'. it will be Set to 1!\n";
            den = 1;
        }

        if (den < 0) {  
            den = -den;
            num = -num;
        }

        int g = gcd(num, den);
        num /= g;
        den /= g;
    }

public:
    RationalNumber(int n = 0, int d = 1) {
        num = n;
        den = d;
        normalize();
    }

    // -------- Arithmetic operators --------
    RationalNumber operator+(const RationalNumber& r) const {
        return RationalNumber(num * r.den + r.num * den, den * r.den);
    }

    RationalNumber operator-(const RationalNumber& r) const {
        return RationalNumber(num * r.den - r.num * den, den * r.den);
    }

    RationalNumber operator*(const RationalNumber& r) const {
        return RationalNumber(num * r.num, den * r.den);
    }

    RationalNumber operator/(const RationalNumber& r) const {
        return RationalNumber(num * r.den, den * r.num);
    }


    // -------- Relational / equality operators --------
    bool operator==(const RationalNumber& r) const {
        return num == r.num && den == r.den;
    }

    bool operator!=(const RationalNumber& r) const {
        return !(*this == r);
    }

    bool operator<(const RationalNumber& r) const {
        return num * r.den < r.num * den;
    }

    bool operator>(const RationalNumber& r) const {
        return r < *this;
    }

    bool operator<=(const RationalNumber& r) const {
        return !(*this > r);
    }

    bool operator>=(const RationalNumber& r) const {
        return !(*this < r);
    }


    // -------- To display --------
    void print() const {
        cout << num << "/" << den;
    }
};


int main() {
    RationalNumber a(1, 2);     
    RationalNumber b(3, 4);     

    cout << "a = "; a.print(); cout << endl;
    cout << "b = "; b.print(); cout << endl;

    RationalNumber sum = a + b;
    RationalNumber diff = a - b;
    RationalNumber prod = a * b;
    RationalNumber quot = a / b;

    cout << "a + b = "; sum.print(); cout << endl;
    cout << "a - b = "; diff.print(); cout << endl;
    cout << "a * b = "; prod.print(); cout << endl;
    cout << "a / b = "; quot.print(); cout << endl;

    
    cout << boolalpha;
    cout << "a == b ? " << (a == b) << endl;
    cout << "a != b ? " << (a != b) << endl;
    cout << "a < b ?  " << (a < b) << endl;
    cout << "a > b ?  " << (a > b) << endl;

    return 0;
}
